=== High Service ===
Contributors:      ernie
Tags:              block
Tested up to:      5.9.6
Stable tag:        0.1.9
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A custom block creating image&text card

== Description ==

Flexible Image/Text card with options border, alignment 

== Installation ==

Pretty much install it as you would any other plugin

1. Upload the plugin files to the `/wp-content/plugins/high-service` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress


== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

<img src="assets/High Service Screenshot.png" alt="High Service Screenshot">
`/assets/High Service Screenshot.png`

== Changelog ==

= 0.1.0 =
* Release


**** 0.1.9

Added border options
changed elenets to use core /media&text
added alignment
